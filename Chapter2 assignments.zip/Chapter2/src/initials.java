/*

Program: initials.java          Last Date of this Revision: September 30, 2019

Purpose: 

Author: Rohaan 
School: CHHS
Course: Computer science 20
 

*/


public class initials {
	
	public static void main(String[] args) 
	{
		System.out.println("------------     ||              ||");
		System.out.println("|          |     | |            | |");
		System.out.println("|          |     |  |          |  |");
		System.out.println("------------     |   |        |   |");
		System.out.println("|     |          |    |      |    |");
		System.out.println("|      |         |     |    |     |");
		System.out.println("|       |        |      |  |      |");
		System.out.println("|        |       |       ||       |");
		
	}
}
/* Screen Dump

------------     ||              ||
|          |     | |            | |
|          |     |  |          |  |
------------     |   |        |   |
|     |          |    |      |    |
|      |         |     |    |     |
|       |        |      |  |      |
|        |       |       ||       |
 */
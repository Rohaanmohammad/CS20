/*

Program: tictactoe.java          Last Date of this Revision: September 30, 2019

Purpose: create a tictactoe board with a x in the center.

Author: Your Name, 
School: CHHS
Course: Computer science 20
 

*/

public class tictactoe {

	public static void main(String[] args) 
	{
		System.out.println("      |         |");
		System.out.println("      |         |");
		System.out.println("      |         |");
		System.out.println("-----------------------");
		System.out.println("      |         |");
		System.out.println("      |    x    |");
		System.out.println("      |         |");
		System.out.println("-----------------------");
		System.out.println("      |         |");
		System.out.println("      |         |");
		System.out.println("      |         |");
	}
	

}

/* Screen Dump

      |         |
      |         |
      |         |
-----------------------
      |         |
      |    x    |
      |         |
-----------------------
      |         |
      |         |
      |         |
 
 */